package com.krishbarcode.reportaccident;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;

public class Home extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        //setContentView(R.layout.activity_home);
    }

    public void acci(View view) {
    }

    public void reportAccident(View view) {
    }

    public void search(View view) {
    }
}
