package com.krishbarcode.firebase_realtime;

import org.junit.Test;

import static org.junit.Assert.*;

/**
 * Created by kritesh on 28/3/18.
 */
public class challanAdapterTest {
    @Test
    public void onCreateViewHolder() throws Exception {
    }

    @Test
    public void onBindViewHolder() throws Exception {
    }

    @Test
    public void getItemCount() throws Exception {
    }

}